require 'test_helper'

class OrdersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
